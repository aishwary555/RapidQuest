import React from 'react';
import { useDropzone } from 'react-dropzone';

const ImageUploader = ({ setEmailData, emailData }) => {
  const onDrop = async (acceptedFiles) => {
    const formData = new FormData();
    formData.append('image', acceptedFiles[0]);

    try {
      const response = await fetch('http://localhost:3000/uploadImage', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Image upload failed');
      }

      const data = await response.json();
      console.log('Uploaded Image URL:', data.imageUrl);
      setEmailData({ ...emailData, image: data.imageUrl });
    } catch (error) {
      console.error('Error uploading image:', error);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({ onDrop });

  return (
    <div {...getRootProps()} style={{ border: '2px dashed #ccc', padding: '10px', margin: '10px 0' }}>
      <input {...getInputProps()} />
      <p>Drag & drop an image here, or click to select one.</p>
    </div>
  );
};

export default ImageUploader;
