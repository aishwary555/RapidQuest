import React from 'react';

const Preview = ({ emailData }) => {
  const { title, content, footer, image } = emailData;

  return (
    <div style={{ border: '1px solid #ccc', padding: '20px', margin: '20px 0', maxWidth: '600px' }}>
      <h1>{title}</h1>
      <div dangerouslySetInnerHTML={{ __html: content }} />
      <p>{footer}</p>
      {image ? (
        <img src={image} alt="Uploaded" style={{ maxWidth: '100%', height: 'auto' }} />
      ) : (
        <p>No image available.</p>
      )}
    </div>
  );
};

export default Preview;
