import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import ImageUploader from './ImageUploader';
import Preview from './Preview';
import './EmailEditor_css.css';


const EmailEditor = () => {
  const [emailData, setEmailData] = useState({
    title: '',
    content: '',
    footer: '',
    image: '',
  });

  const handleChange = (field, value) => {
    setEmailData({ ...emailData, [field]: value });
  };

  const saveTemplate = async () => {
    try {
      const response = await fetch('http://localhost:3000/uploadEmailConfig', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(emailData),
      });

      if (response.ok) {
        alert('Template saved successfully!');
      } else {
        alert('Failed to save template.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error saving template. Please try again.');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <label>Title:</label>
      <ReactQuill value={emailData.title} onChange={(value) => handleChange('title', value)} />
      <label>Content:</label>
      <ReactQuill value={emailData.content} onChange={(value) => handleChange('content', value)} />
      <label>Footer:</label>
      <ReactQuill value={emailData.footer} onChange={(value) => handleChange('footer', value)} />
      <ImageUploader setEmailData={setEmailData} emailData={emailData} />
      <button onClick={saveTemplate}>Save Template</button>
      <Preview emailData={emailData} />
    </div>
  );
};

export default EmailEditor;
