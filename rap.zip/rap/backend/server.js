const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Ensure uploads directory exists
if (!fs.existsSync(path.join(__dirname, 'uploads'))) {
  fs.mkdirSync(path.join(__dirname, 'uploads'), { recursive: true });
}

// Configure Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname); // Get file extension
    const baseName = path.basename(file.originalname, ext); // Get base name
    cb(null, `${baseName}-${Date.now()}${ext}`); // Append timestamp
  },
});

const upload = multer({ storage });

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.post('/uploadImage', upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).send({ message: 'No file uploaded' });
    }
    const imageUrl = `http://localhost:${PORT}/uploads/${req.file.filename}`;
    res.send({ imageUrl });
    console.log(`Image uploaded: ${imageUrl}`);
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).send({ message: 'Failed to upload image' });
  }
});

app.post('/uploadEmailConfig', (req, res) => {
  try {
    const config = req.body;
    if (!config || Object.keys(config).length === 0) {
      return res.status(400).send({ message: 'Invalid configuration data' });
    }
    fs.writeFileSync('emailConfig.json', JSON.stringify(config, null, 2));
    res.send({ message: 'Configuration saved successfully!' });
  } catch (error) {
    console.error('Error saving configuration:', error);
    res.status(500).send({ message: 'Failed to save configuration' });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
